# Publicar la presentación en internet (GitHub + Vercel)

Esta carpeta ya está lista para publicarse tal cual: es un sitio 100% estático
(HTML + imágenes), no necesita servidor ni build.

## Contenido
- `index.html` — la presentación completa
- `p.png`, `logo2.png`, `logoperfil.png`, `meta1.png`…`meta6.png` — las imágenes reales

## Paso 1 — Subir a GitHub

1. Entra a https://github.com/new y crea un repositorio (por ejemplo `presentacion-propiedades`). Puede ser público o privado.
2. En tu computadora, dentro de esta carpeta, ejecuta:
   ```bash
   git init
   git add .
   git commit -m "Presentación ejecutiva Propiedades.com"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/presentacion-propiedades.git
   git push -u origin main
   ```
   (Reemplaza `TU_USUARIO` y el nombre del repo por los tuyos. GitHub te muestra estos mismos comandos exactos al crear el repo vacío.)

## Paso 2 — Conectar con Vercel

1. Entra a https://vercel.com/new
2. Elige "Import Git Repository" y selecciona el repositorio que acabas de crear.
3. Vercel detecta que es un sitio estático — no cambies ninguna configuración de build (déjalo en blanco / "Other").
4. Dale a **Deploy**.
5. En 30-60 segundos tendrás una URL pública tipo `https://presentacion-propiedades.vercel.app` que puedes compartir con quien quieras.

Cada vez que hagas `git push` a `main`, Vercel vuelve a publicar la versión más reciente automáticamente.

## Paso 3 — Conectar Supabase (datos en vivo)

Ya implementé la conexión: `index.html` intenta leer los datos desde una tabla
de Supabase al cargar, y si no puede (porque aún no configuraste las
credenciales, no hay internet, o la tabla está vacía) usa automáticamente los
datos de respaldo que ya vienen incrustados — **la página nunca se rompe**.

1. Entra a https://supabase.com/dashboard y crea un proyecto (o usa uno que ya tengas).
2. Ve a **SQL Editor** → pega el contenido de `supabase_schema_and_seed.sql` (está en esta misma carpeta) → **Run**.
   Esto crea la tabla `dashboard_data`, activa Row Level Security con lectura
   pública (solo lectura, nadie puede escribir con la clave pública), y
   siembra los 4 registros que la presentación necesita: `hist`, `meta`,
   `promos` y `excel_map`.
3. Ve a **Project Settings → API** y copia:
   - **Project URL** (algo como `https://xxxxxxxxxxxx.supabase.co`)
   - **anon public key**
4. Abre `index.html` y busca estas dos líneas cerca del inicio del `<script>` final:
   ```js
   var SUPABASE_URL = 'TU_SUPABASE_URL';
   var SUPABASE_ANON_KEY = 'TU_SUPABASE_ANON_KEY';
   ```
   Reemplázalas con tus valores reales.
5. Guarda, haz `git add . && git commit -m "Conectar Supabase" && git push`.
   Vercel vuelve a publicar solo en unos segundos.

**A partir de ahí:** para actualizar los datos que ve todo el mundo, solo
entras a Supabase → Table Editor → `dashboard_data`, editas el JSON de la
columna `payload` de la fila que quieras (`meta` para los datos de Meta Ads,
`hist` para el histórico, `promos` para las promociones de renovación) y
guardas. No necesitas volver a tocar el código ni a hacer `git push`.

## Paso 4 — Automatizar la actualización diaria (Metabase → Supabase)

Ya no necesitas mover manualmente el Excel. Preparé una función que corre
sola, una vez al día, y actualiza el histórico de leads y el ranking de
avisos directamente desde tu tabla en vivo de Metabase.

**Archivos que ya están en esta carpeta:**
- `api/sync-metabase.js` — la función que hace el trabajo.
- `vercel.json` — le dice a Vercel que la ejecute todos los días a las 9:00 UTC (~3-4 AM CDMX, ajustable).

**Qué actualiza automáticamente:** el histórico de leads/visitas/impresiones
(gráfica de evolución + tabla antes/ahora, slide 4) y el top de avisos con su
Score real (slide 5). **Qué NO toca:** los datos de Meta Ads (inversión, CPL —
slide 3) ni las promociones de renovación (slide 10); esos se siguen editando
a mano desde Supabase.

### Configurar las variables de entorno en Vercel

1. En tu proyecto de Vercel, ve a **Settings → Environment Variables**.
2. Agrega:
   - `SUPABASE_URL` → tu Project URL (la misma del Paso 3).
   - `SUPABASE_SERVICE_ROLE_KEY` → ve a Supabase → Project Settings → API → copia la clave **`service_role`** (la secreta, distinta a la `anon`). **Nunca la pongas en `index.html`** — solo aquí, en Vercel, donde no es visible para el público.
   - (Opcional) `CRON_SECRET` → cualquier texto largo que inventes, para que nadie más pueda disparar la sincronización manualmente.
3. Guarda y vuelve a desplegar (Vercel → Deployments → los tres puntos del último deploy → **Redeploy**), para que la función tome las variables nuevas.

### Probarlo manualmente (antes de esperar al cron)

Abre en tu navegador (reemplazando tu dominio real):
```
https://tu-proyecto.vercel.app/api/sync-metabase
```
Si todo está bien configurado, verás algo como:
```json
{"ok": true, "clientes": ["catano","cattori","mint"], "filas_leidas": 13800, "actualizado": "..."}
```
Si configuraste `CRON_SECRET`, esta prueba manual por navegador fallará con
"No autorizado" (eso es esperado — solo Vercel Cron o alguien con el secreto
puede dispararlo). Para probarlo igual, usa `curl -H "Authorization: Bearer TU_CRON_SECRET" https://tu-proyecto.vercel.app/api/sync-metabase`.

### Confirmar que Supabase se actualizó

Ve a Supabase → Table Editor → `dashboard_data` → abre la fila `hist` o
`ranking` → deberías ver la fecha de `updated_at` recién actualizada.

## Actualizar el inmueble destacado de la slide 6 ("Mejora tu Score")

Esta parte **no tiene forma de automatizarse** (no hay portal para jalar la
foto por `property_id`), así que se actualiza a mano cuando quieras.

**Para actualizarla, dile a Claude exactamente esto:**

> ACTUALIZAR FOTOS SCORE

Y ten a la mano, por cada cliente que quieras actualizar:
- El **property_id** (8 dígitos)
- El **Score**
- La **colonia / ubicación**
- **2 fotos** de ese inmueble

Claude va a reemplazar el objeto `SCORE_PHOTOS` dentro de `index.html` y las
imágenes correspondientes — solo tendrás que volver a subir esos archivos a
GitHub (Vercel republica solo).

**Cómo se comporta esta slide:** cambia según el cliente que elijas en la
barra de control — si seleccionas "MINT", solo se ven las 2 fotos de MINT; si
seleccionas "Todos los clientes", se ven las 3 en columnas lado a lado.
